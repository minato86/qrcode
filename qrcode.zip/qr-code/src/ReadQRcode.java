import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;  
public class ReadQRcode   
{  
	//user-defined method that reads the QR code  
	public static String readQRcode(String path) throws IOException, NotFoundException  
	{  
		BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(ImageIO.read(new FileInputStream(path)))));  
		Result rslt = new MultiFormatReader().decode(binaryBitmap);  
		return rslt.getText();  
	}  
	//main() method  
	public static void main(String args[]) throws  IOException, NotFoundException  
	{  
		//path where the QR code is saved  
		String path = "C:\\Users\\azdean\\qrcode.png";  
		//Encoding charset to be used   
		System.out.println("Data stored in the QR Code is: \n"+ readQRcode(path));  
	}  
}  